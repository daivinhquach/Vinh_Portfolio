from tkinter import *
from StudentClass import *
from tkinter import messagebox
from GUI_Screen3 import GPA_calculation

class Num_student():
    def __init__(self,username):
        self.username = username

    def How_many_student(self):
        '''
        This function run when users finished password successfully and will ask total number of students they want to input
        '''
        root = Tk()
        root.title("Total Number Of Student")# Give atitle to the root window

        ### Welcome user
        text = "Welcome " + self.username + "!"
        student_name = Label(root,text = text,font=("Arial",25))
        student_name.grid(row = 0,column = 1)

        ### Ask user How Many students they want to input
        no_stu = Label(root,text = "Total Student \n (between 1 to 50): ")
        no_stu.grid(row = 2,column = 0)

        no_stu_field = Entry (root, width =50, borderwidth=5) # Creating a field
        no_stu_field.insert(0,0) # positioning the field
        no_stu_field.grid(row= 2, column=1, columnspan=2, padx=5, pady=5)

        ### Checking whether the total number of student within 50 people
        ### Can not input number less than 1 or more than 50
        ### If the condition satisfied then the program show the GPA input interface
        def no_stu_check():
            if 1 <= int(no_stu_field.get())<= 50:
                number_of_student = no_stu_field.get()
                getnumber = GPA_calculation(number_of_student)
                getnumber.student_report()
                root.destroy()
            else:
                messagebox.showerror("Error","Invalid input!!! please fill in the number in the range of 1 to 50")

        next_button = Button(root, text="Next", command = no_stu_check, padx=15, pady=10)
        next_button.grid(row=3,column=2)

        

        


        

        
        
        
    
