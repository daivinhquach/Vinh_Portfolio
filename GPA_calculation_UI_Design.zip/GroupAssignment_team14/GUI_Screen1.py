from tkinter import *
from StudentClass import *
from tkinter import messagebox
from GUI_Screen2 import Num_student


class HitToRun():    
    def Run_Program():
        '''
        This function show the interface of username and password for users to input
        '''
        root = Tk()
        root.title("Account Login")# Give atitle to the root window
        welcomelabel = Label(root,text = "Welcome To Humber College !",font=("Arial", 20))
        welcomelabel.grid(row = 1,column = 1)
        

        userlabel = Label(root,text = "UserName: ")
        userlabel.grid(row = 3,column = 0)

        passwordlabel = Label(root,text = "Password: ")
        passwordlabel.grid(row = 4,column = 0)

        user_field = Entry (root, width =50, borderwidth=5) # Creating a field
        user_field.insert(0,"Input UserName") # positioning the field
        user_field.grid(row= 3, column=1, columnspan=3, padx=10, pady=10)# positioning the field

        password_field = Entry (root, width =50, borderwidth=5) # Creating a field
        password_field.insert(0,"Input PassWord") # positioning the field
        password_field.grid(row= 4, column=1, columnspan=3, padx=10, pady=10)# positioning the field

        NoEntry = []
        def checking_password():
            '''
            This function run when users click log in button and it will check whether the password satisfied the password conditions
            '''
            
            NoEntry.append(1)
            user_pw_enter = password_field.get()
            userpassword = Password(user_pw_enter)
            password_checking_result = userpassword.Password()
            
            userlabel = Label(root,text = password_checking_result[0],justify='left')
            userlabel.grid(row = 5,column = 0)

            ### The message when users enter less than 3 times passwor but failed
            if password_checking_result[2] == "False" and  len(NoEntry) <= 3:
                    password_field.delete(0,END)
                    messagebox.showerror("Login Failed",password_checking_result[1])

            ### The message when users enter more than 3 times password
            elif len(NoEntry) >= 4:
                    messagebox.showerror("Login Failed","You have already filled invalid number 3 times")
                    root.destroy() 

            ### The message when users enter successfully and go to the next interface
            else:
                    messagebox.showinfo("Login Successful", "Welcome To Humber College!")
                    username = user_field.get()
                    get_user_name = Num_student(username)
                    get_user_name.How_many_student()
                    root.destroy()
                    
                   
        ## creating the number buttons   
        signin_button = Button(root, text="Log In", command = checking_password, padx=25, pady=15)
        signin_button.grid(row=7,column=2)

