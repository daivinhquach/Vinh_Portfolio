from GUI_Screen1 import HitToRun

HitToRun.Run_Program()
