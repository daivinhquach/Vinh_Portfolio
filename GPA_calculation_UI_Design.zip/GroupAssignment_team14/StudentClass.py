class StudentScore:
    '''
    This class conclude the function calculating GPA and generate report 
    '''
    ## The hours for each class
    math_crhr = 4
    sceince_crhr =  5
    language_crhr = 4
    drama_crhr = 3
    music_crhr = 2
    biology_crhr = 4

    ### variable to compute the number of student accept or not accept
    notaccept_num =0
    accept_num = 0
    engineer_num = 0
    business_num = 0
    law_num = 0

       
    def __init__(self, name, math, science, language, drama, music, biology):
        self.name = name
        self.math_score = math
        self.science_score = science
        self.language_score = language
        self.drama_score = drama
        self.music_score = music
        self.biology_score = biology

    def score_average(self):
        '''
        This function calculate the average of score for student
        '''
        self.average = (self.math_score * StudentScore.math_crhr +  \
                  self.science_score * StudentScore.sceince_crhr+   \
                  self.language_score * StudentScore.language_crhr+ \
                  self.drama_score* StudentScore.drama_crhr+        \
                  self.music_score * StudentScore.music_crhr+       \
                  self.biology_score * StudentScore.biology_crhr)/  \
                  (StudentScore.math_crhr+StudentScore.sceince_crhr+StudentScore.language_crhr+StudentScore.drama_crhr+StudentScore.music_crhr+StudentScore.biology_crhr)
        return round(self.average,1)
        
    def School_passing(self):
        '''
        This function generate the results of school which students are accepted 
        '''
        if self.average < 70:
            self.school = 'Not Accepted'
            StudentScore.notaccept_num += 1
        elif self.average < 80:
            self.school = "Go to Law School"
            StudentScore.law_num += 1
            StudentScore.accept_num += 1
        elif self.average < 90:
            self.school = "Go to School of Business"
            StudentScore.business_num += 1
            StudentScore.accept_num += 1
        else:
            self.school = "Go to School of Engineering"
            StudentScore.engineer_num += 1
            StudentScore.accept_num += 1
        return self.school


            
class Password:
    '''
    This class conclude functions checking password
    '''
    def __init__(self,password):
        self.password = str(password)
        
    def Password(self):
        '''
        this function helps check the correction of password
        '''
        openmsg = self.password
        length = len(openmsg)
        up_count = 0
        num_count = 0
        sp_count = 0

            ### The password when inputed will be divided into small parts and checking
            ### How many uppercase letter, how many number and how many special case
        for j in range (0,length):
                if openmsg[j].isupper():
                    up_count += 1
                if openmsg[j].isnumeric():
                    num_count += 1
                if not openmsg[j].isalnum():
                    sp_count += 1

            ### The output of password inputed            
        pwmsg = "Length of Your Password: " + str(length) + "\n"\
                    + "No of Upper: " + str(up_count) + "\n"\
                    + "No of Numeric: " + str(num_count) + "\n"\
                    + "No of Special character: "+ str(sp_count)

            ### Checking if the password satisfied the condition           
        if (length < 10)   \
            or (up_count < 1)  \
            or (num_count < 1) and (num_count > 4) \
            or (sp_count != 1) :
                password_logic = "False"
                pw_re = "Your password is invalid \n \
                Should not be less than 10 characters.\n \
                Should contain at least one upper case letter.\n \
                Should contain two or three numbers.\n \
                Should contain one special character."
        else:
                password_logic = "True"
                pw_re = "Successful \n Your password is valid"

        return [pwmsg,pw_re,password_logic]

    
