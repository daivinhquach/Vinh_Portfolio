from StudentClass import *
from tkinter import messagebox
from tkinter import *

class GPA_calculation():
    def __init__(self,NoOfStudent):
        ### Require Expected number of student
        self.NoOfStudent = NoOfStudent
        
    def student_report(self):
        root = Tk()
        root.title("Student Profile")# Give a title to the root window
        totalstudent = self.NoOfStudent
        
        #### create a label ####
        student_name = Label(root,text = "Student Name")
        student_name.grid(row = 2,column = 0)

        math_score = Label(root,text = "Math Score:")
        math_score.grid(row = 3,column = 0)

        science_score = Label(root,text = "Science Score")
        science_score.grid(row = 4,column = 0)

        language_score = Label(root,text = "Language Score")
        language_score.grid(row = 5,column = 0)

        drama_score = Label(root,text = "Drama Score")
        drama_score.grid(row = 6,column = 0)

        music_score = Label(root,text = "Music Score")
        music_score.grid(row = 7,column = 0)

        biology_score = Label(root,text = "Biology Score")
        biology_score.grid(row = 8,column = 0)

        ### create a field ###
        student_field = Entry (root, width =50, borderwidth=5) # Creating a field
        student_field.insert(0,"Input student name") # positioning the field
        student_field.grid(row= 2, column=1, columnspan=2, padx=5, pady=5)# positioning the field


        math_field = Entry (root, width =50, borderwidth=5) # Creating a field
        math_field.insert(0,0) # positioning the field
        math_field.grid(row= 3, column=1, columnspan=2, padx=5, pady=5)# positioning the field


        language_field = Entry (root, width =50, borderwidth=5) # Creating a field
        language_field.insert(0,0)# positioning the field
        language_field.grid(row= 4, column=1, columnspan=2, padx=5, pady=5)# positioning the field


        science_field = Entry (root, width =50, borderwidth=5) # Creating a field
        science_field.insert(0,0)# positioning the field
        science_field.grid(row= 5, column=1, columnspan=2, padx=5, pady=5)# positioning the field


        drama_field = Entry (root, width =50, borderwidth=5) # Creating a field
        drama_field.insert(0,0)# positioning the field
        drama_field.grid(row= 6, column=1, columnspan=2, padx=5, pady=5)# positioning the field


        music_field = Entry (root, width =50, borderwidth=5) # Creating a field
        music_field.insert(0,0)# positioning the field
        music_field.grid(row= 7, column=1, columnspan=2, padx=5, pady=5)# positioning the field


        biology_field = Entry (root, width =50, borderwidth=5) # Creating a field
        biology_field.insert(0,0) # positioning the field
        biology_field.grid(row= 8, column=1, columnspan=2, padx=5, pady=5)# positioning the field

        multiple_stu_result = []
        NoEntry = []
        
        ## Functions ##
        def next_and_save():
            '''
            This function run when users hit Next button to save all information typed in the field into a list
            refresh to type new information
            '''
            ### Control number of student when reach max of total students
            if len(NoEntry) == 0:
                NoEntry.append(1)
            else: NoEntry.append(NoEntry[len(NoEntry)-1]+1)

            if len(NoEntry) > int(totalstudent):
                messagebox.showerror("Error","You exceed " + totalstudent + " students")
                next_button.pack_forget()

            ### If the order of student does not exceed the total students then the program calculate student's average and shool result
            else: 
                student_score = StudentScore(str(student_field.get()),
                                         float(math_field.get()),
                                         float(science_field.get()),
                                         float(language_field.get()),
                                         float(drama_field.get()),
                                         float(music_field.get()),
                                         float(biology_field.get()))
                average_result = student_score.score_average()
                passing_result = student_score.School_passing()
                
                one_stu_result = [str(student_field.get()),
                                         float(math_field.get()),
                                         float(science_field.get()),
                                         float(language_field.get()),
                                         float(drama_field.get()),
                                         float(music_field.get()),
                                         float(biology_field.get()),
                                          average_result,
                                          passing_result]
                multiple_stu_result.append(one_stu_result)
                
                student_field.delete(0,END)
                math_field.delete(0,END)
                language_field.delete(0,END)
                music_field.delete(0,END)
                drama_field.delete(0,END)
                science_field.delete(0,END)
                biology_field.delete(0,END) 

        def finish():
            '''
            This function run when users hit finish button to generate 3 reports
            1/ the detail of each student
            2/ the number of student passed and how many students in each school
            3/ the number of student failed
            '''            
            print('Report 1')
            
            ### Report 1
            report1 = '\n'
            for i in range(len(multiple_stu_result)):    
                one_Stu_text = 'Student Number: ' + str(i) + '\n'+\
                'Student Name: ' + str(multiple_stu_result[i][0]) + '\n'+\
                'Math Score = ' + str(multiple_stu_result[i][1]) + '\n'+\
                'Science Score = ' + str(multiple_stu_result[i][2]) + '\n'+\
                'Language Score = ' + str(multiple_stu_result[i][3]) + '\n'+\
                'Drama Score = ' + str(multiple_stu_result[i][4]) + '\n'+\
                'Music Score = ' + str(multiple_stu_result[i][5]) + '\n'+\
                'Biology Score = ' + str(multiple_stu_result[i][6]) + '\n'+\
                'The average score of ' + str(multiple_stu_result[i][0]) + '= ' + str(multiple_stu_result[i][7])+ '\n'+\
                'Results: ' + str(multiple_stu_result[i][8])+ '\n'+\
                '--------------------------------------------'+'\n'
                report1 = report1 + one_Stu_text

            print(report1)

            ### Report 2
            print('Report 2')
            
            report2 = 'Total number of students accepted = ' + str(StudentScore.accept_num)+ '\n' +\
            'Total number of students assigned to Engineering School = ' + str(StudentScore.engineer_num)+ '\n' +\
            'Total number of students assigned to Business School = ' + str(StudentScore.business_num)+ '\n' +\
            'Total number of students assigned to Law School = ' +  str(StudentScore.law_num)+ '\n' +\
            '-------------------------------------------- \n'

            print(report2)
                
            ### Report 3
            print('Report 3')
            
            report3 = 'Total number of students not accepted = ' + str(StudentScore.notaccept_num) + '\n'+\
            '--------------------------------------------'

            print(report3)

        ## creating the number buttons
        next_button = Button(root, text="Next", command = next_and_save, padx=20, pady=15)
        next_button.grid(row=10,column=1)


        finish_button = Button(root, text="Finish", command = finish, padx=20, pady=15)
        finish_button.grid(row=10,column=2)
            

        # Create an event loop
        root.mainloop()
